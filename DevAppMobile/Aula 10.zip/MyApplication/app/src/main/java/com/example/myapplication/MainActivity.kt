package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavInflater
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.google.gson.Gson

data class Contato(
    val id: Int,
    val nome: String,
    val fone: String,
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Navigator()
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewApp() {
    TelaPrincipal(listOf<Contato>()) {}
}

@Composable
fun Navigator() {
    val navController = rememberNavController()

    val contatos = listOf<Contato>(
        Contato(id=1, nome="Porta 1", fone="11 1111-1111"),
        Contato(id=2, nome="Porta 2", fone="22 2222-2222"),
        Contato(id=3, nome="Porta 3", fone="33 3333-3333"),
        Contato(id=4, nome="Porta 4", fone="44 4444-4444"),
        Contato(id=5, nome="Porta 5", fone="55 55555-5555"),
    )

    NavHost(navController = navController, startDestination = "principal") {
        composable("principal") {
            TelaPrincipal(contatos = contatos,
                onIrDetalhes = {
                    contato ->
                        val contatoJson = Gson().toJson(contato)

                        navController.navigate("detalhes/$contatoJson")
                }
            )
        }

        composable("detalhes/{contatoJson}") {
            backStackEntry ->
                val contatoJson = backStackEntry.arguments?.getString("contatoJson")
                val contato = Gson().fromJson(contatoJson, Contato::class.java)

                TelaDetalhes(contato = contato,
                    onVoltar = {
                        navController.popBackStack()
                    }
                )
        }
    }
}

@Composable
fun TelaPrincipal(contatos: List<Contato>, onIrDetalhes: (contato: Contato) -> Unit) {


    Column (
        modifier = Modifier
            .fillMaxSize()
            .padding(15.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Lista de Contatos", fontSize = 30.sp, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(25.dp))

        LazyColumn() {
            items(contatos) {
                Text(it.nome,
                    fontSize = 22.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onIrDetalhes(it)
                        },
                )
                
                Spacer(modifier = Modifier.height(5.dp))
            }
        }
    }
}

@Composable
fun TelaDetalhes(contato: Contato, onVoltar: () -> Unit) {
    Column (
        modifier = Modifier
            .fillMaxSize()
            .padding(15.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text("Detalhes do Contato", fontSize = 25.sp, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(10.dp))

        Text("Contato: #${contato.id}")
        Spacer(modifier = Modifier.height(10.dp))
        Text("Nome: #${contato.nome}")
        Spacer(modifier = Modifier.height(10.dp))
        Text("Telefone: #${contato.fone}")

        Spacer(modifier = Modifier.height(10.dp))
        Button(onClick = onVoltar) {
            Text("Voltar")
        }
    }
}