package com.example.myapplication.models

data class Jogo(
    var id: Int,
    val nome: String,
)
