package com.example.myapplication.viemodel

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.myapplication.models.Jogo

class JogoViewModel : ViewModel() {

    var listaJogos = mutableStateOf(listOf<Jogo>())
        private set

    private var idJogo = 0

    fun salvarJogo(titulo: String) {
        if (titulo.isBlank()) {
            return;
        }

        val jogo = Jogo(id = 0, nome=titulo)

        jogo.id = idJogo++
        listaJogos.value += jogo
    }

    fun excluirJogo(jogo: Jogo) {

        listaJogos.value = listaJogos.value.filter { it.id != jogo.id }
    }
}
