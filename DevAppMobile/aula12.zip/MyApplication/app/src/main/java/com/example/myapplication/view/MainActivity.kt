package com.example.myapplication.view

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.myapplication.models.Jogo
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.example.myapplication.viemodel.JogoViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                // A surface container using the 'background' color from the theme
                Surface(modifier = Modifier
                    .fillMaxSize()
                    .padding(15.dp), color = MaterialTheme.colorScheme.background) {
                    TelaPrincipal()
                }
            }
        }
    }
}

@Composable
fun TelaPrincipal() {

    val jogoVM: JogoViewModel = viewModel()

    var listaJogos by jogoVM.listaJogos

    Column {
        Text(text = "Cadastrar Jogo",
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = {
             val jogo = Jogo(1, "aaaa")
            jogoVM.salvarJogo(jogo)
        },
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
            )
        {
            Text("Cadastrar")
        }

        LazyColumn() {
            items(listaJogos) {
                Row(Modifier.clickable { jogoVM.excluirJogo(it) }) {
                    Text("ID #${it.id} - ${it.nome}")
                }

                Divider()
            }
        }
    }

}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme {
        Surface(modifier = Modifier
            .fillMaxSize()
            .padding(15.dp), color = MaterialTheme.colorScheme.background) {
            TelaPrincipal()
        }
    }
}