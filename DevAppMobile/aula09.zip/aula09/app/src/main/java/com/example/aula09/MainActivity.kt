package com.example.aula09

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

        }
    }
}

@Composable
fun NavegadorMain() {
    val navController = rememberNavController()
    var tarefas = remember { mutableListOf<Tarefa?>(null) }
    var idTarefaClicada by remember { mutableStateOf<Long?>(null) }

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            TelaPrincipal(tarefas = tarefas,
                onSalvarTarefa = { t, d -> tarefas.add(
                    Tarefa(id=System.currentTimeMillis(), titulo = t, descricao = d)
                ) },
                onIrParaTela={ navController.navigate("detalhes") }
            )
        }

        composable("detalhes") {
            TelaDetalhes(tarefa = tarefas.firstOrNull { it?.id == idTarefaClicada },
                )
        }
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaPrincipal(
    tarefas: MutableList<Tarefa?>,
    onSalvarTarefa: (titulo: String, descricao: String) -> Unit,
    onIrParaTela: (id: Long) -> Unit = {}) {

    var titulo by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    val contexto = LocalContext.current

    Column (modifier = Modifier
        .fillMaxSize()
        .padding(15.dp))
    {
        Text("Bloco de Notas", fontSize = 30.sp)

        Spacer(modifier=Modifier.height(10.dp))

        TextField(value = titulo, onValueChange = {titulo = it}, label = {
            Text("Titulo: ")
        })

        Spacer(modifier=Modifier.height(10.dp))

        TextField(value = desc, onValueChange = {desc = it}, label = {
            Text("Descricao: ")
        })

        Spacer(modifier=Modifier.height(10.dp))

        Button(
            onClick = {
                val novoTitulo = titulo.trim()
                val novaDesc = desc.trim()

                if (novoTitulo.isEmpty() || novaDesc.isEmpty()) {
                    Toast.makeText(contexto, "Preencha os campos necessários", Toast.LENGTH_LONG).show()
                    return@Button
                }

                onSalvarTarefa(novoTitulo, novaDesc)

                titulo = ""
                desc = ""
            },
            enabled = desc.isNotEmpty() && titulo.isNotEmpty()
        ) {
            Text("Salvar")
        }

        Spacer(modifier=Modifier.height(10.dp))

        LazyColumn(modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
            items(tarefas) {
                Row(
                  modifier = Modifier
                      .fillMaxWidth()
                      .padding(15.dp)
                      .clickable { onIrParaTela(it?.id) }

                ) {
                    Text("Tarefa: ${it?.titulo}", fontSize = 18.sp)
                }
            }
        }
    }

}


@Composable
fun TelaDetalhes(tarefa: Tarefa?, onVoltar: () -> Unit = {}) {
    Column (
        modifier = Modifier
            .fillMaxSize()
            .padding(15.dp)
    ) {
        Text("Tela de Detalhes", fontSize = 25.sp)

        Spacer(modifier = Modifier.height(5.dp))

        if (tarefa == null) {
            Text("Tarefa não encontrada")
        } else {

            Text("Titulo: ${tarefa.titulo}")
            Spacer(modifier = Modifier.height(5.dp))

            Text("Descricao: \n ${tarefa.descricao}")

        }

        Button(
            onClick = onVoltar,
            modifier = Modifier.fillMaxSize()
        ) {
            Text("Voltar")
        }
    }
}