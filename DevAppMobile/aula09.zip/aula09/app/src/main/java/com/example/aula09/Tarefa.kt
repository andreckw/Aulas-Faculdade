package com.example.aula09

data class Tarefa(
    val id: Long,
    val titulo: String,
    val descricao: String,
)
