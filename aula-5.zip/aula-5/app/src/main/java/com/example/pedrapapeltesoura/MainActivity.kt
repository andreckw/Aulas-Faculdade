package com.example.pedrapapeltesoura

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pedrapapeltesoura.ui.theme.PedraPapelTesouraTheme
import java.nio.file.WatchEvent

fun rotuloJogada(jogada: Int): String {
    return when (jogada) {
        0 -> "Pedra"
        1 -> "Papel"
        2 -> "Tesoura"
        else -> ""
    }
}

fun verificarResultado(jogador: Int, cpu: Int): String {

    if (jogador == cpu) {
        return "Empate"
    }

    if ((jogador == 0 && cpu == 2) || (jogador == 1 && cpu == 0) || (jogador == 2 && cpu == 1)) {
        return "Venceu"
    }


   return "Perdeste"
}



class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TelaPrincipal()
        }
    }
}

@Composable
fun TelaPrincipal() {

    var escolhaJogador by remember { mutableIntStateOf(-1) }
    var escolhaCpu by remember { mutableIntStateOf(-1) }
    var resultado by remember { mutableStateOf("") }
    var vitorias by remember { mutableIntStateOf(0) }
    var derrotas by remember { mutableIntStateOf(0) }
    var empates by remember { mutableIntStateOf(0) }

    fun processarRodada(escolhaRodada: Int) {
        escolhaJogador = escolhaRodada
        val escolha: List<Int> = listOf(0, 1, 2)
        escolhaCpu = escolha.random()

        resultado = verificarResultado(escolhaJogador, escolhaCpu)

        when (resultado) {
            "Empate" -> empates++
            "Venceu" -> vitorias++
            "Perdeste" -> derrotas++
        }
    }

    Column (
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Pedra, Papel, Tesoura",
            fontSize = 30.sp
        )

        Spacer(modifier = Modifier.height(15.dp))

        Row (
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = { processarRodada(0) }
            ) {
                Text("Pedra")
            }
            Spacer(modifier = Modifier.width(15.dp))
            Button(
                onClick = {
                    processarRodada(1)
                }
            ) {
                Text("Papel")
            }
            Spacer(modifier = Modifier.width(15.dp))
            Button(
                onClick = {
                    processarRodada(2)
                }
            ) {
                Text("Tesoura")
            }
        }

        Spacer(modifier = Modifier.height(15.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Column (
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Voce jogou:", fontSize = 20.sp)
                Spacer(modifier = Modifier.height(15.dp))
                Text(rotuloJogada(escolhaJogador), fontSize = 20.sp)
            }
            Spacer(modifier = Modifier.width(30.dp))
            Column (
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("CPU jogou:", fontSize = 20.sp)
                Spacer(modifier = Modifier.height(15.dp))
                Text(rotuloJogada(escolhaCpu), fontSize = 20.sp)
            }
        }

        Spacer(modifier = Modifier.height(15.dp))

        Text("Resultado: $resultado", fontSize = 25.sp)

        Spacer(modifier = Modifier.height(15.dp))

        Column (
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.End
        ) {
            Text("Vitorias: $vitorias", fontSize = 20.sp)
            Text("Derrotas: $derrotas", fontSize = 20.sp)
            Text("Empates: $empates", fontSize = 20.sp)
        }

        Button(
            onClick = {
                escolhaJogador = -1
                escolhaCpu = -1
                resultado = ""
                vitorias = 0
                derrotas = 0
                empates = 0
            }
        ) {
            Text("Resetar", fontSize = 25.sp)
        }
    }

}


@Preview(showBackground = true)
@Composable
fun PreviewLayout() {
    TelaPrincipal()
}